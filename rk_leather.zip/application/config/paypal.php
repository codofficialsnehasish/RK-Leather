<?php
defined('BASEPATH') OR exit('No direct script access allowed');

// ------------------------------------------------------------------------
// PayPalPro library configuration
// ------------------------------------------------------------------------

// PayPal environment, Sandbox or Live
$config['sandbox'] = TRUE; // FALSE for live environment

// PayPal API credentials
$config['paypal_api_username']	= 'debabrata.mondal0-facilitator_api1.gmail.com';
$config['paypal_api_password']	= 'TV5AQTWC4ECFFFBW';
$config['paypal_api_signature'] = 'AfL8JAkvK-PP8ASnAhGskamGi9c3Ag8Aj5EqpzG-svJrgL6F39brNYt4';