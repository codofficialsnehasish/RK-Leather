<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class About_us extends Core_Controller {
	public function index()
	{
		$this->load->view('partials/header');
		$this->load->view('template/about_us');
		$this->load->view('partials/footer');

	}
}